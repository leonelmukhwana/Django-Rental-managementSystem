import random
import string
from datetime import datetime

from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from multiselectfield import MultiSelectField
from django.urls import reverse




MONTHS_SELECT = [
    ('jan', 'January'),
    ('feb', 'February'),
    ('mar', 'March'),
    ('apr', 'April'),
    ('may', 'May'),
    ('jun', 'June'),
    ('jul', 'July'),
    ('aug', 'August'),
    ('sep', 'September'),
    ('oct', 'October'),
    ('nov', 'November'),
    ('dec', 'December'),
]
# Create your models here.
class CustomUser(AbstractUser):
    user_type_data=((1,"Admin"),(2,"Landlord"),(3,"Tenant"))
    user_type=models.CharField(default=1,choices=user_type_data,max_length=10)

class Admin(models.Model):
    id=models.AutoField(primary_key=True)
    admin=models.OneToOneField(CustomUser,on_delete=models.CASCADE)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    objects=models.Manager()

class Landlord(models.Model):
    id=models.AutoField(primary_key=True)
    admin=models.OneToOneField(CustomUser,on_delete=models.CASCADE)
    phone_no=models.CharField(max_length=50)
    address=models.CharField(max_length=50)
    
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    objects=models.Manager()
    


class Apartment(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=255)    
    location=models.CharField(max_length=255)
    landlord=models.ForeignKey(CustomUser,on_delete=models.CASCADE)
    objects=models.Manager()
    
    def __str__(self):
        return f"{self.name}"
    

        
    
class RoomType(models.Model):
    id=models.AutoField(primary_key=True)
    roomtype = models.CharField(max_length=100, unique=True)
    objects = models.Manager()
        
    def __str__(self):
            return self.roomtype
        


class Room(models.Model):
    STATUS=(
			('Vacant', 'Vacant'),
			('Occupied', 'Occupied'),
			('Under Maintenance', 'Under Maintenance'),
	)
    
    STATUS_FLOOR=(
			('GROUND FLOOR', 'GROUND FLOOR'),
			('FIRST FLOOR', 'FIRST FLOOR'),
			('SECOND FLOOR', 'SECOND FLOOR'),
            ('THIRD FLOOR', 'THIRD FLOOR'),
			('FOURTH FLOOR', 'FOURTH FLOOR'),
			('FIFTH FLOOR', 'FIFTH FLOOR'),
            ('SIXTH FLOOR', 'SIXTH FLOOR'),
			('SEVENTH FLOOR', 'SEVENTH FLOOR'),
			('EIGHTH FLOOR', 'EIGHTH FLOOR'),
            ('NINETH', 'NINETH FLOOR'),
	)
    id = models.AutoField(primary_key=True) 
    apartment = models.ForeignKey(Apartment, null=True, on_delete= models.CASCADE)
    no = models.CharField(max_length=20)
    floor = models.CharField(max_length=200, null=True, choices=STATUS_FLOOR)
    roomtype= models.ForeignKey(RoomType, null=True, on_delete= models.CASCADE)
    rent = models.DecimalField(max_digits=15, decimal_places=2)
    status = models.CharField(max_length=200, null=True, choices=STATUS)
    objects = models.Manager()
    
    def __str__(self):
        return self.no  
      
    
   

class Tenant(models.Model):
    id=models.AutoField(primary_key=True)
    admin=models.OneToOneField(CustomUser,on_delete=models.CASCADE)
    mobile = models.CharField(max_length=15)
    idno=models.CharField(max_length=15)
    gender=models.CharField(max_length=255)
   
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    
    objects = models.Manager()


    def __str__(self):
        return f"{self.full_name}  "

    class Meta:
        verbose_name_plural = 'Tenants'
    
    

class Assign(models.Model):
    
    
   
    tenant = models.ForeignKey(Tenant, on_delete=models.DO_NOTHING)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    
    amount_paid = models.DecimalField(
        max_digits=9, decimal_places=2, default=0)
    pay_for_month = MultiSelectField(choices=MONTHS_SELECT)
    cleared = models.BooleanField(default=False)
    
    
    deposit = models.DecimalField(
        max_digits=9, decimal_places=2, default=0)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    
   
    added = models.DateTimeField(default=datetime.now)
    updated = models.DateTimeField(auto_now=True)
    

    def amount_remaining(self):
        r_amount = (self.room.rent-self.amount_paid)
        return r_amount
    
   
    
    
    def save(self, *args, **kwargs):
        
        Room.objects.filter(pk=self.room_id).update(status='Occupied')
        
        super().save(*args, **kwargs)

    
    def __str__(self):
        return f"{self.tenant} - {self.pay_for_month} "

    class Meta:
        verbose_name_plural = 'Billing 1 | Rent Details'
        verbose_name = 'Rent For Room'  


class PaymentMethods(models.Model):
    name = models.CharField(
        max_length=30, help_text="mpesa, bank transfer e.g. kcb")
    account_name = models.CharField(max_length=50)
    paybill_number = models.CharField(
        max_length=20, null=True, blank=True, help_text='Not required for bank transfer')
    account_number = models.CharField(max_length=30)
    added = models.DateTimeField(default=datetime.now)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'{self.name} - {self.account_number}'

    class Meta:
        verbose_name_plural = 'Payment Options'
        
class NotificationTenant(models.Model):
    id = models.AutoField(primary_key=True)
    tenant_id = models.ForeignKey(Tenant, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)
    objects = models.Manager()
        
        
        
        
class LeaveReportTenant(models.Model):
    id=models.AutoField(primary_key=True)
    tenant_id=models.ForeignKey(Tenant,on_delete=models.CASCADE)
    leave_date=models.CharField(max_length=255)
    leave_message=models.TextField()
    leave_status=models.IntegerField(default=0)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    objects=models.Manager()




class FeedBackTenant(models.Model):
    id = models.AutoField(primary_key=True)
    tenant_id = models.ForeignKey(Tenant, on_delete=models.CASCADE)
    feedback = models.TextField()
    feedback_reply = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)
    objects = models.Manager()

        
        



    


@receiver(post_save,sender=CustomUser)
def create_user_profile(sender,instance,created,**kwargs):
    if created:
        if instance.user_type==1:
            Admin.objects.create(admin=instance)
        if instance.user_type==2:
            Landlord.objects.create(admin=instance,phone_no="",address="")
        if instance.user_type==3:
            Tenant.objects.create(admin=instance,mobile="",idno="",gender="")
       

@receiver(post_save,sender=CustomUser)
def save_user_profile(sender,instance,**kwargs):
    if instance.user_type==1:
        instance.admin.save()
    if instance.user_type==2:
        instance.landlord.save()
    if instance.user_type==3:
        instance.tenant.save()
    

    
        
