import datetime

from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt

from rental_app.models import *


def tenant_home(request):
    tenant_obj=Tenant.objects.get(admin=request.user.id)
    #attendance_total=AttendanceReport.objects.filter(student_id=student_obj).count() 
    return render(request,"tenant/tenant_home.html",{"tenant_obj":tenant_obj})





def tenant_apply_leave(request):
    landlord_obj = Tenant.objects.get(admin=request.user.id)
    leave_data=LeaveReportTenant.objects.filter(tenant_id=landlord_obj)
    return render(request,"tenant/tenant_apply_leave.html",{"leave_data":leave_data})

def tenant_apply_leave_save(request):
    if request.method!="POST":
        return HttpResponseRedirect(reverse("tenant_apply_leave"))
    else:
        leave_date=request.POST.get("leave_date")
        leave_msg=request.POST.get("leave_msg")

        tenant_obj=Tenant.objects.get(admin=request.user.id)
        try:
            leave_report=LeaveReportTenant(tenant_id=tenant_obj,leave_date=leave_date,leave_message=leave_msg,leave_status=0)
            leave_report.save()
            messages.success(request, "Successfully Applied for Leave")
            return HttpResponseRedirect(reverse("tenant_apply_leave"))
        except:
            messages.error(request, "Failed To Apply for Leave")
            return HttpResponseRedirect(reverse("tenant_apply_leave"))


def tenant_feedback(request):
    landlord_id=Tenant.objects.get(admin=request.user.id)
    feedback_data=FeedBackTenant.objects.filter(tenant_id=landlord_id)
    return render(request,"tenant/tenant_feedback.html",{"feedback_data":feedback_data})

def tenant_feedback_save(request):
    if request.method!="POST":
        return HttpResponseRedirect(reverse("tenant_feedback"))
    else:
        feedback_msg=request.POST.get("feedback_msg")

        tenant_obj=Tenant.objects.get(admin=request.user.id)
        try:
            feedback=FeedBackTenant(tenant_id=tenant_obj,feedback=feedback_msg,feedback_reply="")
            feedback.save()
            messages.success(request, "Successfully Sent Feedback")
            return HttpResponseRedirect(reverse("tenant_feedback"))
        except:
            messages.error(request, "Failed To Send Feedback")
            return HttpResponseRedirect(reverse("tenant_feedback"))

def tenant_profile(request):
    user=CustomUser.objects.get(id=request.user.id)
    tenant=Tenant.objects.get(admin=user)
    return render(request,"tenant/tenant_profile.html",{"user":user,"tenant":tenant})

def tenant_profile_save(request):
    if request.method!="POST":
        return HttpResponseRedirect(reverse("tenant_profile"))
    else:
        first_name=request.POST.get("first_name")
        last_name=request.POST.get("last_name")
        password=request.POST.get("password")
        mobile=request.POST.get("mobile")
        idno=request.POST.get("idno")
        try:
            customuser=CustomUser.objects.get(id=request.user.id)
            customuser.first_name=first_name
            customuser.last_name=last_name
            if password!=None and password!="":
                customuser.set_password(password)
            customuser.save()

            tenant=Tenant.objects.get(admin=customuser)
            tenant.mobile=mobile
            tenant.idno=idno
            tenant.save()
            messages.success(request, "Successfully Updated Profile")
            return HttpResponseRedirect(reverse("tenant_profile"))
        except:
            messages.error(request, "Failed to Update Profile")
            return HttpResponseRedirect(reverse("tenant_profile"))

@csrf_exempt
def tenant_fcmtoken_save(request):
    token=request.POST.get("token")
    try:
        tenant=Tenant.objects.get(admin=request.user.id)
        tenant.fcm_token=token
        tenant.save()
        return HttpResponse("True")
    except:
        return HttpResponse("False")

def tenant_all_notification(request):
    tenant=Tenant.objects.get(admin=request.user.id)
    notifications=NotificationTenant.objects.filter(tenant_id=tenant.id)
    return render(request,"tenant/all_notification.html",{"notifications":notifications})

