from datetime import datetime
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views.generic import ListView, DetailView
from rental_app.forms import*
import json
import json
import math
import string
from datetime import datetime
import decimal
from django.db.models import Q, Sum
from django.http import HttpResponse, JsonResponse
from django.http.response import HttpResponseNotFound, JsonResponse
from django.shortcuts import (HttpResponseRedirect, get_object_or_404,
                              redirect, render)
from django.template.loader import get_template, render_to_string
from django.urls import reverse, reverse_lazy
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Sum


from rental_app.models import *
    
current_year = datetime.now().year

current_month = datetime.now().month


def admin_home(request) :
    tenant_count=Tenant.objects.all().count()
    room_count=Room.objects.all().count()
    income_count = Assign.objects.all().aggregate(Sum('amount_paid'))
    apartment_count=Apartment.objects.all().count()
    context={
        'tenant_count':tenant_count,
        'room_count':room_count,
        'apartment_count':apartment_count,
        'income_count':income_count
    }
    
    return render(request, 'admin/home.html',context)   
    
def tenant_home(request):
    return render(request,'admin/tenant_home.html')

def add_landlord(request):
    landlord = Landlord.objects.all()
    form=AddLandlordForm()
    return render(request,"admin/add_landlord.html",{"landlord":landlord,"form":form})

def add_landlord_save(request):
    if request.method!="POST":
        return HttpResponse("Method Not Allowed")
    else:
        form=AddLandlordForm(request.POST,request.FILES)
        if form.is_valid():
            first_name=form.cleaned_data["first_name"]
            last_name=form.cleaned_data["last_name"]
            
            username=form.cleaned_data["username"]
            email=form.cleaned_data["email"]
            password=form.cleaned_data["password"]
            phone_no=form.cleaned_data["phone_no"]
            address=form.cleaned_data["address"]
            

         

            try:
                user=CustomUser.objects.create_user(username=username,password=password,email=email,last_name=last_name,first_name=first_name,user_type=2)
                
                user.landlord.phone_no=phone_no
                user.landlord.address=address
                
                user.save()
                messages.success(request,"Successfully Added Landlord")
                return HttpResponseRedirect(reverse("add_landlord"))
            except:
                messages.error(request,"Failed to Add Landlord")
                return HttpResponseRedirect(reverse("add_landlord"))
        else:
            form=AddLandlordForm(request.POST)
            return render(request, "admin/add_landlord.html", {"form": form})


def manage_landlord(request):
    
    landlord=Landlord.objects.all()
    return render(request,"admin/manage_landlord.html",{"landlord":landlord})



def edit_landlord(request,landlord_id):
    landlord=Landlord.objects.get(admin=landlord_id)
    return render(request,"admin/edit_landlord.html",{"landlord":landlord,"id":landlord_id})

def edit_landlord_save(request):
    if request.method!="POST":
        return HttpResponse("<h2>Method Not Allowed</h2>")
    else:
        landlord_id=request.POST.get("landlord_id")
        first_name=request.POST.get("first_name")
        last_name=request.POST.get("last_name")
        email=request.POST.get("email")
        username=request.POST.get("username")
        phone_no=request.POST.get("phone_no")
        address=request.POST.get("address")

        try:
            user=CustomUser.objects.get(id=landlord_id)
            user.first_name=first_name
            user.last_name=last_name
            user.email=email
            user.username=username
            user.save()

            landlord_model=Landlord.objects.get(admin=landlord_id)
            landlord_model.phone_no=phone_no
            landlord_model.address=address
            landlord_model.save()
            messages.success(request,"Successfully Edited Landlord")
            return HttpResponseRedirect(reverse("edit_landlord",kwargs={"landlord_id":landlord_id}))
        except:
            messages.error(request,"Failed to Edit Landlord")
            return HttpResponseRedirect(reverse("edit_landlord",kwargs={"landlord_id":landlord_id}))





def add_apartment(request):
    apartment=Apartment.objects.all()
    
    landlord=CustomUser.objects.filter(user_type=2)
    return render(request, "admin/add_apartment.html",{"apartment":apartment,"landlord":landlord})

def add_apartment_save(request):
    if request.method!="POST":
        return HttpResponse("<h2>Method Not Allowed</h2>")
    else:
        name=request.POST.get("name")
        location=request.POST.get("location")
        
        landlord=request.POST.get("landlord")
        landlord=CustomUser.objects.get(id=landlord)

        try:
            apartment=Apartment(name=name,location=location,landlord=landlord)
            apartment.save()
            
            messages.success(request,"Successfully Added Apartment")
            return HttpResponseRedirect(reverse("add_apartment"))
        except:
            messages.error(request,"Failed to Add Apartment")
            return HttpResponseRedirect(reverse("add_apartment"))







def edit_apartment(request,apartment_id):
    apartment=Apartment.objects.get(id=apartment_id)
    
    landlord=CustomUser.objects.filter(user_type=2)
    return render(request,"admin/edit_apartment.html",{"apartment":apartment,"landlord":landlord,"id":apartment_id})

def edit_apartment_save(request):
    if request.method!="POST":
        return HttpResponse("<h2>Method Not Allowed</h2>")
    else:
        apartment_id=request.POST.get("apartment_id")
        apartment_name=request.POST.get("apartment_name")
        apartment_location=request.POST.get("apartment_location")
        landlord_id=request.POST.get("landlord")
        

        try:
            apartment=Apartment.objects.get(id=apartment_id)
            apartment.apartment_name=apartment_name
            apartment.apartment_location=apartment_location
            landlord=CustomUser.objects.get(id=landlord_id)
            apartment.landlord_id=landlord
            
            apartment.save()

            messages.success(request,"Successfully Edited Apartment")
            return HttpResponseRedirect(reverse("add_apartment",kwargs={"apartment_id":apartment_id}))
        except:
            messages.error(request,"Failed to Edit Apartment")
            return HttpResponseRedirect(reverse("add_apartment",kwargs={"apartment_id":apartment_id}))
def delete_apartment(request,apartment_id):  
    apartment = Apartment.objects.get(id=apartment_id)  
    apartment.delete() 
    return render(request,"admin/add_apartment.html")     


def add_roomtype(request):
    if 'query' in request.GET:
        query = request.GET['query']
        roomtype = RoomType.objects.filter(roomtype__icontains=query)
    else:
        roomtype = RoomType.objects.all()
    context={
        'roomtype':roomtype
    }
    
    return render(request, "admin/add_roomtype.html",context)


def add_roomtype_save(request):
    if request.method!="POST":
        return HttpResponse("<h2>Method Not Allowed</h2>")
    else:
        roomtype=request.POST.get("roomtype")
        
       

        try:
            roomtype=RoomType(roomtype=roomtype)
            roomtype.save()
            
            messages.success(request,"Successfully Added RoomType")
            return HttpResponseRedirect(reverse("add_roomtype"))
        except:
            messages.error(request,"Failed to Add RoomType")
            return HttpResponseRedirect(reverse("add_roomtype"))



    
       

        

def edit_roomtype(request,roomtype_id):
    roomtype=RoomType.objects.get(id=roomtype_id)
    return render(request,"admin/edit_roomtype.html",{"roomtype":roomtype,"id":roomtype_id})

def edit_roomtype_save(request):
    if request.method!="POST":
        return HttpResponse("<h2>Method Not Allowed</h2>")
    else:
        roomtype_id=request.POST.get("roomtype_id")
        roomtype=request.POST.get("roomtype")

        try:
            roomtype=RoomType.objects.get(id=roomtype_id)
            
            roomtype.roomtype=roomtype
            roomtype.save()
            messages.success(request,"Successfully Edited RoomType")
            return HttpResponseRedirect(reverse("edit_roomtype",kwargs={"roomtype_id":roomtype_id}))
        except:
            messages.error(request,"Failed to Edit RoomType")
            return HttpResponseRedirect(reverse("edit_roomtype",kwargs={"roomtype_id":roomtype_id}))

def delete_roomtype(request,roomtype_id):  
    roomtype = RoomType.objects.get(id=roomtype_id)  
    roomtype.delete() 
    return render(request,"admin/add_roomtype.html")  







def add_room(request):
    room = Room.objects.all()
    form = RoomForm()
    if request.method == 'POST':
		#print('Printing POST:', request.POST)
        form = RoomForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                messages.success(request,"Successfully Added Room")
                return HttpResponseRedirect(reverse("add_room"))
            except:
                messages.error(request,"Failed to Add Room")
                return HttpResponseRedirect(reverse("add_room"))
    context = {'form':form,'room':room}
    return render(request, 'admin/add_room.html', context)

def updateRoom(request, pk):

	order = Room.objects.get(id=pk)
	form = RoomForm(instance=order)

	if request.method == 'POST':
		form = RoomForm(request.POST, instance=order)
		if form.is_valid():
			form.save()
			return redirect('/')

	context = {'form':form}
	return render(request, 'admin/edit_room.html', context)

def deleteRoom(request, pk):
	order = Room.objects.get(id=pk)
	if request.method == "POST":
		order.delete()
		return redirect('/')

	context = {'item':order}
	return render(request, 'accounts/delete.html', context)




def add_tenant(request):
    form=AddTenantForm()
    return render(request,"admin/add_tenant.html",{"form":form})

def add_tenant_save(request):
    if request.method!="POST":
        return HttpResponse("Method Not Allowed")
    else:
        form=AddTenantForm(request.POST)
        if form.is_valid():
            first_name=form.cleaned_data["first_name"]
            last_name=form.cleaned_data["last_name"]
            username=form.cleaned_data["username"]
            email=form.cleaned_data["email"]
            password=form.cleaned_data["password"]
            mobile=form.cleaned_data["mobile"]
            
            idno=form.cleaned_data["idno"]
            gender=form.cleaned_data["gender"]

           
            try:
                user=CustomUser.objects.create_user(username=username,password=password,email=email,last_name=last_name,first_name=first_name,user_type=3)
                user.tenant.mobile=mobile               
                user.tenant.idno=idno                
                user.tenant.gender=gender
                
                user.save()
                messages.success(request,"Successfully Added Tenant")
                return HttpResponseRedirect(reverse("add_tenant"))
            except:
                messages.error(request,"Failed to Add Tenant")
                return HttpResponseRedirect(reverse("add_tenant"))
        else:
            form=AddTenantForm(request.POST)
            return render(request, "admin/add_tenant.html", {"form": form})





def manage_tenant(request):

    tenant=Tenant.objects.all()
    return render(request,"admin/manage_tenant.html",{"tenant":tenant})



def edit_tenant(request,tenant_id):
    tenant=Tenant.objects.get(admin=tenant_id)
    return render(request,"admin/edit_tenant.html",{"tenant":tenant,"id":tenant_id})

def edit_tenant_save(request):
    if request.method!="POST":
        return HttpResponse("<h2>Method Not Allowed</h2>")
    else:
        tenant_id=request.POST.get("tenant_id")
        first_name=request.POST.get("first_name")
        last_name=request.POST.get("last_name")
        email=request.POST.get("email")
        username=request.POST.get("username")
        contact=request.POST.get("contact")
        idno=request.POST.get("idno")
        

        try:
            user=CustomUser.objects.get(id=tenant_id)
            user.first_name=first_name
            user.last_name=last_name
            user.email=email
            user.username=username
            user.save()

            tenant_model=Tenant.objects.get(admin=tenant_id)
            tenant_model.contact=contact
            tenant_model.idno=idno
            tenant_model.save()
            messages.success(request,"Successfully Edited Tenant")
            return HttpResponseRedirect(reverse("edit_tenant",kwargs={"tenant_id":tenant_id}))
        except:
            messages.error(request,"Failed to Edit Tenant")
            return HttpResponseRedirect(reverse("edit_tenant",kwargs={"tenant_id":tenant_id}))


def tenant_profile(request):
    user=CustomUser.objects.get(id=request.user.id)
    tenant=Tenant.objects.get(admin=user)
    return render(request,"admin/tenant_profile.html",{"user":user,"tenant":tenant})

def tenant_profile_save(request):
    if request.method!="POST":
        return HttpResponseRedirect(reverse("tenant_profile"))
    else:
        first_name=request.POST.get("first_name")
        last_name=request.POST.get("last_name")
        password=request.POST.get("password")
        contact=request.POST.get("contact")
        idno=request.POST.get("idno")
        try:
            customuser=CustomUser.objects.get(id=request.user.id)
            customuser.first_name=first_name
            customuser.last_name=last_name
            if password!=None and password!="":
                customuser.set_password(password)
            customuser.save()

            tenant=Tenant.objects.get(admin=customuser)
            tenant.contact=contact
            tenant.idno=idno
            tenant.save()
            messages.success(request, "Successfully Updated Profile")
            return HttpResponseRedirect(reverse("tenant_profile"))
        except:
            messages.error(request, "Failed to Update Profile")
            return HttpResponseRedirect(reverse("tenant_profile"))



def delete_tenant(request,tenant_id):  
    tenant = Tenant.objects.get(id=tenant_id)  
    tenant.delete() 
   
    return render(request,"admin/add_tenant.html") 

def view_tenant(request, tenant_id):
    tenant = Tenant.objects.get(id=tenant_id)
    context={
        'tenant':tenant
    }
    return render(request, 'admin/view_tenant.html', context)



def assign_room(request,room_id):
    room = Room.objects.get(id=room_id)
    if room.status == 'occupied':
        messages.error(request,"The room is Occupied")
        return HttpResponseRedirect(reverse("assign_room"))
    else:
        if request.method == 'POST':
            form = AddRentDetailsForm(request.POST)
            if form.is_valid():
                
                form.save()
                messages.success(request, 'Rent added successfully')
                
            else:
                form = AddRentDetailsForm()
        else:
            messages.success(request,"The room is Empty")
            return HttpResponseRedirect(reverse("assign_room"))
    context = {'form':form}
    return render(request, 'admin/add_room.html', context)






def add_rent_detail(request):
    assign = Assign.objects.all()
    form = AddRentDetailsForm()
    if request.method == 'POST':
		#print('Printing POST:', request.POST)
        form = AddRentDetailsForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                messages.success(request,"Successfully Rent details")
                return HttpResponseRedirect(reverse("add_rent_detail"))
            except:
                messages.error(request,"Failed to Add Rent details for")
                return HttpResponseRedirect(reverse("add_rent_detail"))
    context = {'form':form,'assign':assign}
    return render(request, 'admin/rent_details.html', context)



def vacant(request):
    vacant =Room.objects.filter(status='Vacant')
    return render(request,'admin/vacant.html',{'vacant':vacant})


def occupied(request):
    vacant =Room.objects.filter(status='Occupied')
    return render(request,'admin/occupied.html',{'vacant':vacant})

def book_room(request):
    tenant=Tenant.objects.all()
    room = Room.objects.all().get(id=int(request.GET['roomid']))
    
    return HttpResponse(render(request,'admin/assign_room.html',{'room':room,'tenant':tenant}))


def rent_room(request):
    
    if request.method =="POST":

        room_id = request.POST['room_id']
        
        room = Room.objects.all().get(id=room_id)
        #for finding the reserved rooms on this time period for excluding from the query set
        
        

        assign = Assign()
        room_object = Room.objects.all().get(id=room_id)
        room_object.status = 'Occupied'
        
        
        assign.room = room_object
        
        tenant=request.POST.get("tenant")
        tenant=Tenant.objects.get(id=tenant)
        assign.tenant=tenant
        assign.amount_paid= request.POST.get('amount_paid')
        assign.deposit= request.POST.get('deposit')
        assign.pay_for_month= request.POST.get('pay_for_month')
        assign.start_date= request.POST.get('start_date')
        
        assign.end_date= request.POST.get('end_date')
        

        assign.save()

        messages.success(request,"Congratulations! Booking Successfull")

        return redirect("vacant")
    else:
        return HttpResponse('Access Denied')
    
def rent_detail(request):
    
    assign = Assign.objects.all()
    if not assign:
        messages.warning(request,"No Rented Room Found")
    return HttpResponse(render(request,'admin/view_assign.html',{'assign':assign}))





@csrf_exempt
def check_email_exist(request):
    email=request.POST.get("email")
    user_obj=CustomUser.objects.filter(email=email).exists()
    if user_obj:
        return HttpResponse(True)
    else:
        return HttpResponse(False)

@csrf_exempt
def check_username_exist(request):
    username=request.POST.get("username")
    user_obj=CustomUser.objects.filter(username=username).exists()
    if user_obj:
        return HttpResponse(True)
    else:
        return HttpResponse(False)



def tenant_feedback_message(request):
    feedbacks=FeedBackTenant.objects.all()
    return render(request,"admin/tenant_feedback.html",{"feedbacks":feedbacks})

@csrf_exempt
def tenant_feedback_message_replied(request):
    feedback_id=request.POST.get("id")
    feedback_message=request.POST.get("message")

    try:
        feedback=FeedBackTenant.objects.get(id=feedback_id)
        feedback.feedback_reply=feedback_message
        feedback.save()
        return HttpResponse("True")
    except:
        return HttpResponse("False")





def tenant_leave_view(request):
    leaves=LeaveReportTenant.objects.all()
    return render(request,"admin/tenant_leave_view.html",{"leaves":leaves})

def tenant_approve_leave(request,leave_id):
    leave=LeaveReportTenant.objects.get(id=leave_id)
    leave.leave_status=1
    leave.save()
    return HttpResponseRedirect(reverse("tenant_leave_view"))

def tenant_disapprove_leave(request,leave_id):
    leave=LeaveReportTenant.objects.get(id=leave_id)
    leave.leave_status=2
    leave.save()
    return HttpResponseRedirect(reverse("tenant_leave_view"))









def admin_profile(request):
    user=CustomUser.objects.get(id=request.user.id)
    return render(request,"admin/admin_profile.html",{"user":user})

def admin_profile_save(request):
    if request.method!="POST":
        return HttpResponseRedirect(reverse("admin_profile"))
    else:
        first_name=request.POST.get("first_name")
        last_name=request.POST.get("last_name")
        password=request.POST.get("password")
        try:
            customuser=CustomUser.objects.get(id=request.user.id)
            customuser.first_name=first_name
            customuser.last_name=last_name
            # if password!=None and password!="":
            #     customuser.set_password(password)
            customuser.save()
            messages.success(request, "Successfully Updated Profile")
            return HttpResponseRedirect(reverse("admin_profile"))
        except:
            messages.error(request, "Failed to Update Profile")
            return HttpResponseRedirect(reverse("admin_profile"))

def admin_send_notification_tenant(request):
    tenant=Tenant.objects.all()
    return render(request,"admin/tenant_notification.html",{"tenant":tenant})



@csrf_exempt
def send_tenant_notification(request):
    id=request.POST.get("id")
    message=request.POST.get("message")
    tenant=Tenant.objects.get(admin=id)
    token=tenant.fcm_token
    url="https://fcm.googleapis.com/fcm/send"
    body={
        "notification":{
            "title":"Student Management System",
            "body":message,
            "click_action": "https://studentmanagementsystem22.herokuapp.com/student_all_notification",
            "icon": "http://studentmanagementsystem22.herokuapp.com/static/dist/img/user2-160x160.jpg"
        },
        "to":token
    }
    headers={"Content-Type":"application/json","Authorization":"key=SERVER_KEY_HERE"}
    data=request.post(url,data=json.dumps(body),headers=headers)
    notification=NotificationTenant(tenant_id=tenant,message=message)
    notification.save()
    print(data.text)
    return HttpResponse("True")




