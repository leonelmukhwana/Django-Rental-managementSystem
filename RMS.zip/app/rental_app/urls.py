from django.urls import path
from . import views, AdminViews,TenantViews


urlpatterns = [
     
     path('', views.show_login_page,name='show_login_page'),
     #path('home', AdminViews.home,name='home'),
     path('doLogin',views.doLogin, name='do_login'),
     path('logout_user', views.logout_user,name="logout"),
     
     #adminviews
     path('admin_home', AdminViews.admin_home,name="admin_home"),
     
     path('add_landlord', AdminViews.add_landlord,name="add_landlord"),
     path('add_landlord_save', AdminViews.add_landlord_save,name="add_landlord_save"),
     path('manage_landlord',AdminViews.manage_landlord,name="manage_landlord"),
     path('add_landlord_save',AdminViews.add_landlord_save,name="add_landlord_save"),
     path('edit_landlord/<str:landlord_id>', AdminViews.edit_landlord,name="edit_landlord"),
     path('edit_landlord_save', AdminViews.edit_landlord_save,name="edit_landlord_save"),
     
     path('add_apartment',AdminViews.add_apartment,name="add_apartment"),
   
     
     path('add_apartment_save', AdminViews.add_apartment_save,name="add_apartment_save"),
     path('edit_apartment/<str:apartment_id>', AdminViews.edit_apartment,name="edit_apartment"),
     path('edit_apartment_save', AdminViews.edit_apartment_save,name="edit_apartment_save"),
     path('delete_apartment/<str:apartment_id>', AdminViews.delete_apartment,name="delete_apartment"),
     path('add_roomtype',AdminViews.add_roomtype,name="add_roomtype"),
     path('add_roomtype_save',AdminViews.add_roomtype_save,name="add_roomtype_save"),
     path('edit_roomtype/<str:roomtype_id>',AdminViews.edit_roomtype,name="edit_roomtype"),
     path('edit_roomtype_save',AdminViews.edit_roomtype_save,name="edit_roomtype_save"),
     path('delete_roomtype/<str:roomtype_id>', AdminViews.delete_roomtype,name="delete_roomtype"),
     
    
     
     
     path('add_room',AdminViews.add_room,name="add_room"),
     #path('add_room_save',AdminViews.add_room_save,name="add_room_save"),
     # path('search',AdminViews.search,name="search"),
     
     
     path('add_tenant',AdminViews.add_tenant,name="add_tenant"),
     path('view_tenant/<str:tenant_id>', AdminViews.view_tenant,name="view_tenant"),
     path('add_tenant_save',AdminViews.add_tenant_save,name="add_tenant_save"),
     path('manage_tenant',AdminViews.manage_tenant,name="manage_tenant"),
     path('edit_tenant/<str:tenant_id>',AdminViews.edit_tenant,name="edit_tenant"),
     path('edit_tenant_save',AdminViews.edit_tenant_save,name="edit_tenant_save"),
     path('delete_tenant/<str:tenant_id>', AdminViews.delete_tenant,name="delete_tenant"),
     path('assign_room/<str:room_id>',AdminViews.assign_room,name="assign_room"),
     #path('populate',AdminViews.populate,name="populate"),
     #path('add_tenant_rent/<str:room_id>/', AdminViews.add_tenant_rent, name='add_tenant_rent'),
     path('add_rent_detail', AdminViews.add_rent_detail, name='add_rent_detail'),
     
     path('vacant', AdminViews.vacant, name='vacant'),
     path('occupied', AdminViews.occupied, name='occupied'),
     path('book_room', AdminViews.book_room, name='book_room'),
     path('rent_room', AdminViews.rent_room, name='rent_room'),
     path('rent_detail', AdminViews.rent_detail, name='rent_detail'),
     
     #admin urls
     path('check_email_exist', AdminViews.check_email_exist,name="check_email_exist"),
     path('check_username_exist', AdminViews.check_username_exist,name="check_username_exist"),
     path('tenant_feedback_message', AdminViews.tenant_feedback_message,name="tenant_feedback_message"),
     path('tenant_feedback_message_replied', AdminViews.tenant_feedback_message_replied,name="tenant_feedback_message_replied"),    
     path('tenant_leave_view', AdminViews.tenant_leave_view,name="tenant_leave_view"),    
     path('tenant_approve_leave/<str:leave_id>', AdminViews.tenant_approve_leave,name="tenant_approve_leave"),
     path('tenant_disapprove_leave/<str:leave_id>', AdminViews.tenant_disapprove_leave,name="tenant_disapprove_leave"),   
     
     path('admin_profile', AdminViews.admin_profile,name="admin_profile"),
     path('admin_profile_save', AdminViews.admin_profile_save,name="admin_profile_save"),    
     path('admin_send_notification_tenant', AdminViews.admin_send_notification_tenant,name="admin_send_notification_tenant"),
     path('send_tenant_notification', AdminViews.send_tenant_notification,name="send_tenant_notification"),
     

     
     
     #tennt urls
     path('tenant_home', TenantViews.tenant_home, name="tenant_home"),
     
     path('tenant_apply_leave', TenantViews.tenant_apply_leave, name="tenant_apply_leave"),
     path('tenant_apply_leave_save', TenantViews.tenant_apply_leave_save, name="tenant_apply_leave_save"),
     path('tenant_feedback', TenantViews.tenant_feedback, name="tenant_feedback"),
     path('tenant_feedback_save', TenantViews.tenant_feedback_save, name="tenant_feedback_save"),
     path('tenant_profile', TenantViews.tenant_profile, name="tenant_profile"),
     path('tenant_profile_save', TenantViews.tenant_profile_save, name="tenant_profile_save"),
     path('tenant_fcmtoken_save', TenantViews.tenant_fcmtoken_save, name="tenant_fcmtoken_save"),
     path('firebase-messaging-sw.js',views.showFirebaseJS,name="show_firebase_js"),
     path('tenant_all_notification',TenantViews.tenant_all_notification,name="tenant_all_notification"),
     
     path('testurl/',views.Testurl)
     
     

     
    
     
]