from django import forms
from django.forms import ChoiceField
from django.forms import ModelForm

from rental_app.models import *




class ChoiceNoValidation(ChoiceField):
    def validate(self, value):
        pass

class DateInput(forms.DateInput):
    input_type = "date"

class AddLandlordForm(forms.Form):
    email=forms.EmailField(label="Email",max_length=50,widget=forms.EmailInput(attrs={"class":"form-control","autocomplete":"off"}))
    password=forms.CharField(label="Password",max_length=50,widget=forms.PasswordInput(attrs={"class":"form-control"}))
    first_name=forms.CharField(label="First Name",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    last_name=forms.CharField(label="Last Name",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    
    username=forms.CharField(label="Username",max_length=50,widget=forms.TextInput(attrs={"class":"form-control","autocomplete":"off"}))
    phone_no=forms.CharField(label="Mobile Number",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    address=forms.CharField(label="Address",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    
    
class AddTenantForm(ModelForm):
    class Meta:
        model = Tenant
        fields = '__all__' 
        
       

class AddTenantForm(forms.Form):
    email=forms.EmailField(label="Email",max_length=50,widget=forms.EmailInput(attrs={"class":"form-control","autocomplete":"off"}))
    password=forms.CharField(label="Password",max_length=50,widget=forms.PasswordInput(attrs={"class":"form-control"}))
    first_name=forms.CharField(label="First Name",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    last_name=forms.CharField(label="Last Name",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    username=forms.CharField(label="Username",max_length=50,widget=forms.TextInput(attrs={"class":"form-control","autocomplete":"off"}))
    mobile=forms.CharField(label="Mobile No.",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    idno=forms.CharField(label="ID NO/Passport",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
  

    gender_choice=(
        ("Male","Male"),
        ("Female","Female")
    )

    
    gender=forms.ChoiceField(label="Gender",choices=gender_choice,widget=forms.Select(attrs={"class":"form-control"}))
    

class EditTenantForm(forms.Form):
    email=forms.EmailField(label="Email",max_length=50,widget=forms.EmailInput(attrs={"class":"form-control"}))
    first_name=forms.CharField(label="First Name",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    last_name=forms.CharField(label="Last Name",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    username=forms.CharField(label="Username",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    mobile=forms.CharField(label="Mobile No.",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))
    idno=forms.CharField(label="ID NO/Passport",max_length=50,widget=forms.TextInput(attrs={"class":"form-control"}))


    

    gender_choice=(
        ("Male","Male"),
        ("Female","Female")
    )

    
    gender=forms.ChoiceField(label="Gender",choices=gender_choice,widget=forms.Select(attrs={"class":"form-control"}))
    




class RoomForm(ModelForm):
	class Meta:
		model = Room
		fields = '__all__' 
        
        
        
       
       

            

        
        
